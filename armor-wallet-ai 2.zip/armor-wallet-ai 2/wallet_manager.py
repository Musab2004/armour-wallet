import requests
import os

from client import UserCredentials
 
URL=os.getenv("URL")
user_credentials = UserCredentials()
class WalletManager:
    def __init__(self):
        self.wallets = ""

    def get_all_wallets(self):
        headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
        try:
            response = requests.get(f"{URL}/api/v1/wallets/", headers=headers)
            if response.status_code==200:
                response_json = response.json()
                wallets = []
                for wallet in response_json.get('results', []):
                    wallets.append(f"Wallet Name: {wallet.get('name')}, Address: {wallet.get('public_address')}, Archived: {wallet.get('is_archived')}")
                return wallets
            else:
                return f"Failed to get wallets {response.status_code}"
        except Exception as e:
            return f"Failed to get wallets {e}"
