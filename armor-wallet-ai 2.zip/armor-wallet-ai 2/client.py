import json

class UserCredentials:
    def __init__(self):
        
        try:
            with open('credentials.json', 'r') as f:
                creds = json.load(f)
                username = creds.get('username', '')
                password = creds.get('password', '')
                access_secret = creds.get('access_token', '')
        except FileNotFoundError:
            username = ''
            password = ''
            access_secret = ''

        self._username = username
        self._password = password 
        self._access_secret = access_secret

    def initialize(self, username: str, password: str, access_secret: str) -> None:
        """Initialize user credentials"""
        self._username = username
        self._password = password
        self._access_secret = access_secret

    def get_username(self) -> str:
        """Get username"""
        return self._username

    def get_password(self) -> str:
        """Get password"""
        return self._password
    
    def get_access_secret(self) -> str:
        """Get access secret"""
        return self._access_secret
