from dotenv import load_dotenv
import chainlit as cl
import os

from langchain_core.messages import HumanMessage, AIMessage
from langchain.globals import set_debug, set_verbose
from graph import app
from langsmith import traceable

import json
from langgraph.types import Command
import requests



set_debug(True)
set_verbose(True)

load_dotenv()




URL=os.getenv("URL")


@cl.password_auth_callback
def auth_callback(username: str, password: str):

    if (username, password) == (os.getenv("EMAIL"), os.getenv("PASSWORD")):
        return cl.User(
            identifier=os.getenv("EMAIL"), metadata={"role": "admin", "provider": os.getenv("PASSWORD")}
        )
    else:
        return None

@cl.on_chat_start
async def on_chat_start():
    cl.user_session.set("chat_history", [])
    cl.user_session.set("all_tasks", [])
    app_user = cl.user_session.get("user")
    email=app_user.identifier
    password=app_user.metadata['provider']
    response = requests.post(f"{URL}/api/v1/users/login/", json={"email":email,"password":password})
    response.raise_for_status()
    response=response.json()
    if "access" in response:
        token=response['access']
        try:
            with open("credentials.json", "w") as f:
                credentials = {
                    "username": email,
                    "password": password,
                    "access_token": token
                }
                json.dump(credentials, f, indent=4)
            msg = cl.Message(content="Hey hi welcome to armour wallet!")
            await msg.send()
        except Exception as e:
            msg = cl.Message(content="Hey hi welcome to armour wallet! some issue we are facing")
            print(f"Error saving credentials: {str(e)}")

    else:
        msg = cl.Message(content="Invalid credentials")



@cl.on_message
@traceable(name="ON Message")
async def on_message(message: cl.Message):
        chat_history = cl.user_session.get("chat_history")
        token=cl.user_session.get("token")
        msg = cl.Message(content="")
        thread_config = {"configurable": {"thread_id": "2"}}
        if chat_history==[]:
            inputs = {"query": message.content, "chat_history": chat_history, "response":"","human_feedback":"","token":token}
            state=app.invoke(inputs, thread_config)
            msg.content=state['response']
            chat_history.extend(
                [HumanMessage(content=message.content), AIMessage(content=msg.content)]
            )
            await msg.send()
            await msg.update()
        else:
            state=app.invoke(Command(resume=message.content), thread_config)
            msg.content=state['response']
            chat_history.extend(
                [HumanMessage(content=message.content), AIMessage(content=msg.content)]
            )
            await msg.send()
            await msg.update()
