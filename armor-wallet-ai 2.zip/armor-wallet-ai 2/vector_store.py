from uuid import uuid4
import json
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
import faiss
from langchain_community.docstore.in_memory import InMemoryDocstore
from langchain_community.vectorstores import FAISS
from langsmith import traceable
from dotenv import load_dotenv

load_dotenv()

class TokenVectorStore:
    def __init__(self):
        self.embeddings = OpenAIEmbeddings(model="text-embedding-3-large")
        self.vector_store = FAISS.load_local(
            "tokens_vector_store", self.embeddings, allow_dangerous_deserialization=True
        )

    def get_vector_store(self):
        return self.vector_store
    @traceable(name="get_token_documents")
    def get_token_documents(self, session_id):
        documents = []
        with open('tokens_list.json') as f:
            tokens = json.load(f)
            
        for token in tokens:
            name = token.get('name', 'No Name')
            symbol = token.get('symbol', 'NA') 
            address = token.get('address', 'NA')
            
            document = Document(
                page_content=f'{name} ({symbol}) - {address}',
                metadata={
                    'session_id': session_id,
                    'name': name,
                    'symbol': symbol,
                    'address': address,
                    'decimals': token.get('decimals'),
                    'daily_volume': token.get('daily_volume'),
                    'created_at': token.get('created_at')
                }
            )
            documents.append(document)
        return documents

    @traceable(name="store_vectors") 
    def store_vectors(self, documents):
        uuids = [str(uuid4()) for _ in range(len(documents))]
        self.vector_store.add_documents(documents=documents, ids=uuids)
        return uuids
        
    def similarity_search(self, query, k=1, filter=None):
        results = self.vector_store.similarity_search(query, k=k, filter=filter)
        tokens = []
        all_token_strings = ""
        for result in results:
            token_md = f"**Token Name**: {result.metadata['name']}\n**Symbol**: {result.metadata['symbol']}"
            all_token_strings += f"{token_md}\n"
            tokens.append({"symbol": result.metadata["symbol"], "name": result.metadata["name"], "markdown": token_md})

        return all_token_strings






