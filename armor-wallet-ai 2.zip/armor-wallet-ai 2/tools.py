import os
import requests
from dotenv import load_dotenv
from langchain.pydantic_v1 import BaseModel, Field
from langchain_core.tools import tool
from client import UserCredentials
from vector_store import TokenVectorStore
from wallet_manager import WalletManager

load_dotenv()


user_credentials = UserCredentials()
token_store = TokenVectorStore()
wallet_manager = WalletManager()

URL=os.getenv("URL")
# Token Operations Tools
class SwapQuoteInput(BaseModel):
    wallet_name: str = Field(description="Name of the wallet")
    input_token_symbol: str = Field(description="Symbol of token to sell (e.g. in 'swap 10 SOL with WIF', SOL is the input_token_symbol)")
    output_token_symbol: str = Field(description="Symbol of token to buy (e.g. in 'swap 10 SOL with WIF', WIF is the output_token_symbol)")
    amount_to_sell: float = Field(description="Amount of input token to sell (e.g. in 'swap 10 SOL with WIF', 10 is the amount_to_sell)")
class SwapQuotesInput(BaseModel):
    quotes: list[SwapQuoteInput] = Field(description="List of swap quotes. It could be only one quote as well")
@tool
def get_swap_quote(input: SwapQuotesInput) -> str:
    """Get quote for swapping tokens. After successful quote generation, ask if you want to proceed with the swap by typing 'proceed'"""
    all_quotes = []
    all_transactions = []
    for quote in input.quotes:
        headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
        response = requests.post(f"{URL}/api/v1/transactions/swap-quote/", headers=headers, json={"wallet_name": quote.wallet_name, "input_token_symbol": quote.input_token_symbol, "output_token_symbol": quote.output_token_symbol,"type": "SWAP", "input_amount": quote.amount_to_sell})
        response_json = response.json()
        all_transactions.append(response_json)
        quotes_text = "\n".join(all_transactions)

        quotes_text = "\n".join(all_quotes)
        return f"{quotes_text}"

class TransferTokenInput(BaseModel):
    from_wallet_name: str = Field(description="Source wallet name")
    to_wallet_address: str = Field(description="Destination wallet address")
    input_token_symbol: str = Field(description="Token symbol to transfer like")
    input_amount: float = Field(description="Amount to transfer")

class TransferTokensInput(BaseModel):
    transfers: list[TransferTokenInput] = Field(description="List of transfer tokens")
@tool
def transfer_tokens(input: TransferTokensInput) -> str:
    """Execute token transfer between wallets"""
    all_transactions = []
    for transfer in input.transfers:
        headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
        response = requests.post(f"{URL}/api/v1/transactions/transfer/", headers=headers, json={
            "from_wallet_name": transfer.from_wallet_name,
            "to_wallet_address": transfer.to_wallet_address, 
            "input_token_symbol": transfer.input_token_symbol,
            "input_amount": transfer.input_amount
        })
        response_json = response.json()
        all_transactions.append(f"Response: {response_json}")
    return "\n".join(all_transactions)

class LimitOrderInput(BaseModel):
    wallet_name: str = Field(description="Name of the wallet")
    selling_token: str = Field(description="Token to sell")
    buying_token: str = Field(description="Token to buy")
    input_amount: float = Field(description="Amount to sell")
    is_input_amount_in_percentage: bool = Field(description="Whether input amount is a percentage")
    condition_type: str = Field(description="Type of price condition (e.g. price_rise)")
    target_value: float = Field(description="Target price or percentage")
    is_target_value_in_percentage: bool = Field(description="Whether target value is a percentage")
    expiry_amount: int = Field(description="Time until expiry")
    expiry_unit: str = Field(description="Unit for expiry time (hours/days/weeks)")

class LimitOrdersInput(BaseModel):
    orders: list[LimitOrderInput] = Field(description="List of limit orders")
@tool
def validate_limit_order(input: LimitOrdersInput) -> str:
    """Validate limit order placement"""
    all_transactions = []
    for order in input.orders:
        transaction_id = hash(f"{order.wallet_name}{order.selling_token}{order.buying_token}{order.input_amount}{order.target_value}") % 1000000
        amount_type = "%" if order.is_input_amount_in_percentage else ""
        target_type = "%" if order.is_target_value_in_percentage else ""
        all_transactions.append(f"Limit order from wallet {order.wallet_name} to sell {order.input_amount}{amount_type} {order.selling_token} for {order.buying_token} when price {order.condition_type} by {order.target_value}{target_type} is successfully placed. Order expires in {order.expiry_amount} {order.expiry_unit}. Transaction ID: {transaction_id}")
    return "\n".join(all_transactions)

class StakeTokenInput(BaseModel):
    token_symbol: str = Field(description="Token to stake")
    stake_amount: float = Field(description="Amount to stake")

class StakeTokensInput(BaseModel):
    stakes: list[StakeTokenInput] = Field(description="List of stake tokens")

@tool
def validate_stake_tokens(input: StakeTokensInput) -> str:
    """Validate token staking"""
    all_transactions = []
    for stake in input.stakes:
        transaction_id = hash(f"{stake.token_symbol}{stake.stake_amount}") % 1000000
        all_transactions.append(f"Staking {stake.stake_amount} {stake.token_symbol} is successfully placed. Its transaction id is {transaction_id}")
    return "\n".join(all_transactions)

class DCAOrderInput(BaseModel):
    input_token: str = Field(description="Token you're spending (e.g. SOL in 'DCA 50 SOL into GOAT' where SOL is what you're spending)")
    input_amount: float = Field(description="Total amount to spend (e.g. 50 SOL in 'DCA 50 SOL into GOAT' where 50 SOL is the total amount)")
    output_token: str = Field(description="Token you're buying (e.g. GOAT in 'DCA into GOAT' where GOAT is what you're acquiring)")
    interval: int = Field(description="Time between purchases (e.g. 1 for daily, 7 for weekly)")
    frequency_unit: str = Field(description="Unit of time between purchases (days/weeks/months) - e.g. 'days' for daily purchases")
    total_periods: int = Field(description="Total number of periods to run the DCA strategy (e.g. 30 for 30 days)")
    condition: str = Field(description="Whether to execute on price rise or drop")
    condition_percentage: float = Field(description="Target percentage change to trigger DCA")
    wallet_name: str = Field(description="Wallet to use for DCA")
class DCAOrdersInput(BaseModel):
    orders: list[DCAOrderInput] = Field(description="List of DCA orders")
@tool
def validate_dca_order(input: DCAOrdersInput) -> str:
    """Validate DCA order setup"""
    all_transactions = []
    for order in input.orders:
        transaction_id = hash(f"{order.input_token}{order.input_amount}{order.output_token}{order.interval}{order.frequency_unit}{order.total_periods}{order.condition}{order.condition_percentage}{order.wallet_name}") % 1000000
        all_transactions.append(f"DCA order to buy {order.input_amount} {order.input_token} daily for {order.interval} {order.frequency_unit} is successfully placed. Transaction ID: {transaction_id}")
    return "\n".join(all_transactions)


class SlippageInput(BaseModel):
    slippage_percentage: float = Field(description="Slippage percentage")

@tool
def set_slippage(input: SlippageInput) -> str:
    """slippage setting"""
    return f"Global slippage set to {input.slippage_percentage}% is successful"

# Wallet Group Management Tools
class GroupInput(BaseModel):
    group_names: list[str] = Field(description="List of group names to create", default_factory=list)

@tool
def group_creation(input: GroupInput) -> str:
    """wallet group creation"""
    if not input.group_names:
        # Create default group names if none provided
        headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
        for group_name in input.group_names:
            requests.post(f"{URL}/api/v1/wallets/groups/create/", json={"name": group_name}, headers=headers)
    return f"Creating groups {input.group_names} is successful"

@tool
def list_groups() -> str:
    """List all wallet groups"""
    headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
    response = requests.get(f"{URL}/api/v1/wallets/groups/", headers=headers)
    return f"Groups: {response.json()}"

class GroupInput(BaseModel):
    group_name: str = Field(description="Name of the group. It is an optional value if not provided, give it default value of", default="")
@tool
def list_wallets(input: GroupInput) -> str:
    """List wallets in a group"""
    if input.group_name == "":

        headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
        response = requests.get(f"{URL}/api/v1/wallets/", headers=headers)
    else:
        headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
        response = requests.get(f"{URL}/api/v1/wallets/{input.group_name}", headers=headers)
    return f"Wallets in {input.group_name}: {response.json()}"

class GroupWalletInput(BaseModel):
    wallet_names: list[str] = Field(description="List of wallet names")
    group_name: str = Field(description="Name of the group")

@tool
def add_wallets_to_group(input: GroupWalletInput) -> str:
    """Add wallets to a group"""
    headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
    response = requests.post(f"{URL}/api/v1/wallets/add-to-group/", headers=headers, json={"wallet_names": input.wallet_names, "group_name": input.group_name})
    return f"response: {response.json()}"


class GroupWalletInput(BaseModel):
    wallet_names: list[str] = Field(description="List of wallet names")
    group_name: str = Field(description="Name of the group")

@tool
def remove_wallets_from_group(input: GroupWalletInput) -> str:
    """Remove wallets from a group"""
    headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
    response = requests.post(f"{URL}/api/v1/wallets/remove-from-group/", headers=headers, json={"wallet_names": input.wallet_names, "group_name": input.group_name})
    return f"response: {response.json()}"


class UpdateGroupInput(BaseModel):
    current_name: str = Field(description="Current group name")
    new_name: str = Field(description="New group name")

@tool
def group_update(input: UpdateGroupInput) -> str:
    """group update"""
    return f"Updating group name from '{input.current_name}' to '{input.new_name}' is successful"

# Wallet Operations Tools
class WalletInput(BaseModel):
    wallet_names: list[str] = Field(description="List of wallet names. if no names are provided, it will create default names")
    number_of_wallets:int= Field(description="Number of wallets to create")
    names_provided:bool= Field(description="Whether names are provided")

@tool
def wallet_creation(input: WalletInput) -> str:
    """Create a new wallets. if no names provided and number of wallets is provided, ask user to if he wants to create default names then create wallets and keep group names empty"""
    # wallet_manager.create_wallet(input.wallet_names)
    all_wallets = []
    if input.names_provided:
        for wallet_name in input.wallet_names:
            all_wallets.append({"name": wallet_name})
    else:
        for i in range(input.number_of_wallets):
            all_wallets.append({})

    headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
    response = requests.post(f"{URL}/api/v1/wallets/", headers=headers, json={"names": all_wallets})
    if response.status_code == 200:
        response_json = response.json()
        return f"Wallets created successfully {response.json()}"
    else:
        return f"Failed to create wallets {response.json()}"

class WalletInputArchive(BaseModel):
    wallet_names: list[str] = Field(description="List of wallet names to archive")
@tool
def wallet_archive(input: WalletInputArchive) -> str:
    """wallet archiving"""
    headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
    response = requests.post(f"{URL}/api/v1/wallets/archive/", headers=headers, json={"names": input.wallet_names})
    return f"Archiving wallet '{input.wallet_names}' is successful"

class WalletInputUnarchive(BaseModel):
    wallet_names: list[str] = Field(description="List of wallet names to unarchive")
@tool
def wallet_unarchive(input: WalletInputUnarchive) -> str:
    """wallet unarchiving"""
    headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
    response = requests.post(f"{URL}/api/v1/wallets/unarchive/", headers=headers, json={"names": input.wallet_names})
    return f"Successfully unarchived wallets {input.wallet_names}"

class GroupInputArchive(BaseModel):
    group_names: list[str] = Field(description="List of group names to archive")
@tool
def group_archive(input: GroupInputArchive) -> str:
    """group archiving"""
    headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
    response = requests.post(f"{URL}/api/v1/groups/archive/", headers=headers, json={"names": input.group_names})
    return f"response: {response.json()}"

class GroupInputUnarchive(BaseModel):
    group_names: list[str] = Field(description="List of group names to unarchive")
@tool
def group_unarchive(input: GroupInputUnarchive) -> str:
    """group unarchiving"""
    headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
    response = requests.post(f"{URL}/api/v1/groups/unarchive/", headers=headers, json={"names": input.group_names})
    return f"response: {response.json()}"

class WalletInputDetails(BaseModel):
    wallet_names: list[str] = Field(description="List of wallet names to get details")
@tool
def wallet_details(input: WalletInputDetails) -> str:
    """Get wallet details"""
    headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
    all_details = []
    for wallet_name in input.wallet_names:
        response = requests.get(f"{URL}/api/v1/wallets/detail/{wallet_name}/", headers=headers)
        details = response.json()
        all_details.append(details)
    return f"Response: {all_details}"

class TokenInput(BaseModel):
    token_symbol: str = Field(description="Symbol of the token")

@tool
def get_token_info(input: TokenInput) -> str:
    """Get token information including price, market cap, supply, volume and price history"""
    vector_store = token_store.get_vector_store()
    results = vector_store.similarity_search(input.token_symbol, k=1)
    return f"Token '{input.token_symbol}' information: {results}"
    
class SwapTransactionInput(BaseModel):
    transaction_id: int = Field(description="Transaction ID")


@tool
def perform_transaction(input: SwapTransactionInput) -> str:
    """Execute the swap transaction with given ID only after explicit user confirmation (e.g. 'proceed'). This can be used only for swap quotes."""
    headers = {"Authorization": f"Bearer {user_credentials.get_access_secret()}"}
    response = requests.post(f"{URL}/api/v1/transactions/swap-send/", headers=headers, json={"transaction_id": input.transaction_id})
    return f"response: {response.json()}"


tools = [get_swap_quote, get_token_info, transfer_tokens, validate_limit_order, validate_stake_tokens, validate_dca_order, set_slippage, group_creation, list_groups, list_wallets, add_wallets_to_group, group_update, wallet_creation, wallet_archive, wallet_unarchive, wallet_details,perform_transaction]
