from typing import List
from typing_extensions import TypedDict
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph, START
from langgraph.types import Command, interrupt
from vector_store import TokenVectorStore
from wallet_manager import WalletManager
from langgraph.prebuilt import create_react_agent
from tools import tools
from dotenv import load_dotenv
from langgraph.checkpoint.memory import MemorySaver

load_dotenv()



wallet_manager = WalletManager()
token_store = TokenVectorStore()

class GraphState(TypedDict):
    chat_history: List[str]
    query: str
    response: str


    
def api_validation_node(state):
    print("api_validation_node")
    retrieved_tokens=token_store.similarity_search(state['query'], k=100)
    available_wallets = wallet_manager.get_all_wallets()
    prompt = f"""You are a helpful assistant that identifies the appropriate tool to use and validates required parameters.

    Available wallets:
    <available_wallets>
    {available_wallets}
    </available_wallets>

    Available tokens:
    <available_tokens>
    {retrieved_tokens}
    </available_tokens>

    For each tool call:
    1. Check if all required parameters are present based on the tool's input schema
    2. If any parameters are missing:
    - List out all missing parameters that the user needs to provide
    - Format the response as: "Please provide the following parameters to proceed:\n- [parameter 1]\n- [parameter 2]"
    3. If all parameters are present:
    - Execute the tool
    - Return the tool response wrapped in triple backticks (```)
    - Format any transaction details or confirmations within the backticks
    4. one small thing here 100$ is regarded as 100 USDC(input_token is USDC and amount is 100)

    Always validate parameters before executing tools to ensure complete information."""


    llm = ChatOpenAI(model="gpt-4o")
    validation_agent_executor = create_react_agent(llm, tools, state_modifier=prompt)
    messages = []
    for chat in state["chat_history"]:
        messages.append({"role": "user", "content": chat["user_message"]})
        messages.append({"role": "assistant", "content": chat["assistant_message"]})
    messages.append({"role": "user", "content": state['query']})
    
    response = validation_agent_executor.invoke({"messages": messages})
    state["response"] = response['messages'][-1].content
    state["chat_history"].append({"user_message":state['query'],"assistant_message":response['messages'][-1].content})

    goto="human_feedback_new_start_analyzer"
    return Command(
        update=state,
        goto=goto,
    )


def human_feedback_new_start_analyzer(state):
    human_feedback=interrupt(state)
    state["query"]=human_feedback
    return state


checkpointer = MemorySaver()



workflow = StateGraph(GraphState)
workflow.add_node("api_validation", api_validation_node)
workflow.add_node("human_feedback_new_start_analyzer", human_feedback_new_start_analyzer)

workflow.add_edge(START, "api_validation")
workflow.add_edge("human_feedback_new_start_analyzer", "api_validation")



app = workflow.compile(checkpointer=checkpointer)